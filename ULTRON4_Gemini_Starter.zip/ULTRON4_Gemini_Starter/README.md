# ULTRON4 — Gemini starter

This project is a mobile-friendly chat website connected to Google's Gemini API through a server route.

## Important privacy and security notes
- The Gemini API key belongs only in the server environment variable `GEMINI_API_KEY`.
- Never put the key in `app/page.tsx`, browser JavaScript, a public HTML file, or any variable beginning with `NEXT_PUBLIC_`.
- This starter does not save conversations in a database. Messages are sent to Google's Gemini API to generate responses.
- Tell visitors that their messages are sent to Google Gemini before they use the site. Do not secretly monitor visitors' chats.
- API free-tier availability, quotas, model access, and age/account requirements depend on Google's current terms and region. Check Google AI Studio before relying on free usage.
- Add rate limiting and abuse protection before sharing widely. A public API endpoint can incur usage against your API account.

## Configure locally
1. Install Node.js on a computer or use a hosting platform that can build Next.js projects.
2. Copy `.env.example` to `.env.local`.
3. Put your key after `GEMINI_API_KEY=`. Never share it.
4. Choose a model available in your AI Studio account using `GEMINI_MODEL`.
5. Run `npm install`, then `npm run dev`.

## Deploy
This is a Next.js project, not a single HTML file. To make a public website, deploy it to a host that supports Next.js server routes (for example, Vercel).
1. Upload this project to a private GitHub repository.
2. Import that repository into your hosting provider.
3. Add `GEMINI_API_KEY` and `GEMINI_MODEL` in the hosting provider's Environment Variables settings.
4. Deploy. Do not commit `.env.local` or paste the key into source files.

## Mobile note
You can download and inspect this ZIP on Android, but deploying a Next.js backend still requires a hosting service. The HTML demo alone cannot safely hold a private API key.
