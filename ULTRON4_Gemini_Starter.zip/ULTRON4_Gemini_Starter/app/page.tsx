 "use client";

import { FormEvent, useState } from "react";

type Message = { role: "user" | "model"; text: string };

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "model", text: "System online. I'm Ultron4 — direct, practical, and honest. What's on your mind?" }
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function sendMessage(event: FormEvent) {
    event.preventDefault();
    const text = input.trim();
    if (!text || busy) return;

    const next: Message[] = [...messages, { role: "user", text }];
    setMessages(next);
    setInput("");
    setError("");
    setBusy(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next.slice(-20) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Something went wrong.");
      setMessages([...next, { role: "model", text: data.reply }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to reach Gemini.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="shell">
      <header>
        <div className="brand">
          <div className="mark">U4</div>
          <div><h1>ULTRON4</h1><div className="sub">PERSONAL INTELLIGENCE INTERFACE</div></div>
        </div>
        <div className="status">● GEMINI CONNECTED</div>
      </header>

      <section className="intro">
        <div className="orb">✳</div>
        <h2>THINK CLEARER.</h2>
        <p>No unnecessary noise. Ask a question, test an idea, or get a direct answer.</p>
      </section>

      <div className="privacy">
        <strong>Privacy:</strong> Your messages are sent to Google's Gemini API to generate replies.
        This starter does not save chat history on its own. Don't enter passwords or sensitive personal information.
      </div>

      <section className="chat" aria-live="polite">
        {messages.map((message, index) => (
          <div className={`msg ${message.role === "user" ? "user" : "bot"}`} key={index}>
            {message.role === "model" && <div className="tag">ULTRON4</div>}
            {message.text}
          </div>
        ))}
        {busy && <div className="msg bot"><div className="tag">ULTRON4</div>Thinking...</div>}
        <div id="bottom" />
      </section>

      {error && <p className="error">{error}</p>}
      <form className="composer" onSubmit={sendMessage}>
        <div className="entry">
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder="Message Ultron4..."
            rows={1}
            maxLength={4000}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                (event.currentTarget.form as HTMLFormElement | null)?.requestSubmit();
              }
            }}
          />
          <button type="submit" disabled={!input.trim() || busy}>{busy ? "..." : "Send"}</button>
        </div>
        <div className="foot">ULTRON4 · POWERED BY GOOGLE GEMINI</div>
      </form>
    </main>
  );
}