import { NextRequest, NextResponse } from "next/server";

type ChatMessage = { role: "user" | "model"; text: string };

const SYSTEM_INSTRUCTION = `
You are ULTRON4, a direct, practical, honest AI assistant.
Be concise and clear. Avoid excessive praise, fake certainty, and unnecessary filler.
Disagree respectfully when needed. Ask one focused clarifying question if essential information is missing.
Do not pretend to be human. Explain uncertainty honestly.
`;

export async function POST(request: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";

    if (!apiKey) {
      return NextResponse.json(
        { error: "Gemini isn't configured yet. Add GEMINI_API_KEY in your hosting environment variables." },
        { status: 503 }
      );
    }

    const body = await request.json();
    const messages = body.messages as ChatMessage[];

    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
      return NextResponse.json({ error: "Invalid chat history." }, { status: 400 });
    }

    const contents = messages.map((message) => {
      if (!["user", "model"].includes(message.role) || typeof message.text !== "string") {
        throw new Error("Invalid message format.");
      }
      return { role: message.role, parts: [{ text: message.text.slice(0, 4000) }] };
    });

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    const geminiResponse = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 900 }
      }),
      cache: "no-store"
    });

    const result = await geminiResponse.json();
    if (!geminiResponse.ok) {
      const message = result?.error?.message || "Gemini request failed. Check your model and API key.";
      return NextResponse.json({ error: message }, { status: geminiResponse.status });
    }

    const reply = result?.candidates?.[0]?.content?.parts
      ?.map((part: { text?: string }) => part.text || "")
      .join("")
      .trim();

    if (!reply) {
      return NextResponse.json({ error: "Gemini returned an empty response. Try again." }, { status: 502 });
    }

    return NextResponse.json({ reply });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unexpected server error.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}